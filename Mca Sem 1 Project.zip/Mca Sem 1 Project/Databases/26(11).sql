-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 26, 2023 at 01:54 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `accessories`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `cart_id` int(11) NOT NULL,
  `product_name` varchar(225) NOT NULL,
  `product_price` varchar(11) NOT NULL,
  `product_image` varchar(255) NOT NULL,
  `qty` int(11) NOT NULL,
  `total_price` varchar(255) NOT NULL,
  `product_code` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `category_id` int(10) NOT NULL,
  `category_name` varchar(255) NOT NULL,
  `category_description` varchar(255) NOT NULL,
  `category_image` varchar(255) NOT NULL,
  `created` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`category_id`, `category_name`, `category_description`, `category_image`, `created`) VALUES
(1, 'PVC', 'PVC stands for Polyvinyl Chloride. It is strong and durable and resistant to large amounts of stress. This makes it a suitable material for underground pipes and pipes through which pressurized fluids need to pass. ', '../img/card1.jpeg', '2023-09-11 15:10:45'),
(2, 'U-PVC', 'UPVC stands for Unplasticized Polyvinyl Chloride, which is a type of piping that is made from PVC plastic.', '../img/card2.jpeg', '2023-09-11 17:30:16'),
(3, 'C-PVC', 'CPVC stands for Chlorinated Polyvinyl Chloride which means more chlorine has been added to PVC. CPVC products are thermoplastic and are made with CPVC resins.', '../img/card3.jpeg', '2023-09-11 17:33:35');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `address` varchar(225) NOT NULL,
  `pay_mode` varchar(255) NOT NULL,
  `products` varchar(255) NOT NULL,
  `amount_paid` varchar(255) NOT NULL,
  `order_status` int(11) NOT NULL,
  `pay_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `name`, `email`, `phone`, `address`, `pay_mode`, `products`, `amount_paid`, `order_status`, `pay_status`) VALUES
(1, 'chetan', 'chetanmiyatra156@hotmail.com', '9638521470', 'it is good', 'cod', 'PVC Pipes(17), UPVC Pipes(16)', '8200', 1, 1),
(2, 'chetan', 'chetanmiyatra156@hotmail.com', '9638521470', 'it is good', 'cod', '', '0', 0, 1),
(3, 'SAHIL', 'SAHIL@GMAIL.COM', '9632587410', 'IT IS GOOD PRODUCT.', 'cod', 'UPVC Pipes(6), PVC Pipes(6)', '3000', 0, 0),
(4, 'chetan', 'chetanmiyatra056@gmail.com', '1234569870', 'It is a good product.', 'cod', 'PVC Pipes(10), PVC Elbow(15), PVC Tee(12)', '3710', 0, 0),
(5, 'chetan', 'chetanmiyatra056@gmail.com', '1234569870', 'It is a good.', 'cod', 'PVC Pipes(2), UPVC Tee(2), UPVC Solution(2)', '1100', 0, 0),
(6, 'yash barochiya', 'yash@gmail.com', '1234569870', '360410', 'cards', 'PVC Pipes(5), UPVC Pipes(3), PVC Elbow(1), UPVC Elbow(1), PVC Solution(2), UPVC Solution(3)', '3720', 0, 0),
(7, 'vijaya', 'vijaya@gmail.com', '7418529630', 'it is good product.', 'cod', 'UPVC Elbow(30), UPVC Pipes(20), UPVC Tee(1)', '8150', 0, 0),
(8, 'kishan', 'kishan@gmail.com', '1234569870', 'timbavadi', 'cod', 'PVC Pipes(2), UPVC Elbow(10), PVC Union(1)', '1250', 0, 0),
(9, 'chetan', 'chetanmiyatra056@gmail.com', '1234569870', 'it is good Product.', 'cod', 'PVC Pipes(1)', '200', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `product_id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_desc` text NOT NULL,
  `product_image` varchar(255) NOT NULL,
  `product_price` int(11) NOT NULL,
  `product_qty` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `product_code` varchar(255) NOT NULL,
  `uploaded_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`product_id`, `product_name`, `product_desc`, `product_image`, `product_price`, `product_qty`, `category_id`, `product_code`, `uploaded_date`) VALUES
(1, 'PVC Pipes', 'The finished product is a white or light-colored plastic that is rigid and durable. PVC pipes are used for a variety of purposes, including water and wastewater conveyance, electrical wiring, and plumbing.', '../img/PVC C1.jpeg', 200, 1, 1, 'p1000', '2023-09-18 15:47:31'),
(2, 'UPVC Pipes', 'It or unplasticised polyvinyl chloride is a type of PVC that is produced without any added plasticisers.', '../img/uPVC C2.jpeg', 300, 1, 2, 'p1001', '2023-11-07 12:12:34'),
(3, 'CPVC Pipes', 'It has also been used extensively in fire sprinkler systems since 1985. This material is also used for many industrial and process piping applications.', '../img/cPVC C3.jpeg', 500, 1, 3, 'p1002', '2023-09-18 15:50:14'),
(4, 'PVC Elbow', 'It provide high performance along with high durability, long service life, easy installation and does not require regular maintenance. ', '../img/pvc-elbow.jpg', 50, 1, 1, 'p1003', '2023-09-24 12:31:41'),
(5, 'UPVC Elbow', 'It 90°Elbow Pipe fittings are made from a specifically developed unplasticized polyvinyl chloride compound. ', '../img/upvc-elbow.jpeg', 70, 1, 2, 'p1004', '2023-09-24 12:42:58'),
(6, 'CPVC Elbow', 'It elbow fittings are plastic fittings that are used to connect two pipes at a specific angle. This is done to provide flexibility, reduce friction and turbulence in the plumbing systems.', '../img/cpvc-elbow.jpeg', 90, 1, 3, 'p1005', '2023-09-24 12:45:23'),
(7, 'PVC Tee', 'It Fitting has three sockets in a tee-shape configuration, all at 90-degree angles to the other. FORMUFIT Structural Grade PVC Tee fitting joins PVC pipe at three frame and structure interconnections points.', '../img/pvc-tee.jpeg', 80, 1, 1, 'p1006', '2023-09-26 17:12:34'),
(8, 'UPVC Tee', 'It tee, the most common pipe fitting, is used to combine or divide fluid flow. It is available with female thread sockets, solvent-weld sockets or opposed solvent-weld sockets and a female-threaded side outlet.', '../img/upvc-tee.jpeg', 50, 1, 2, 'p1007', '2023-09-26 17:14:01'),
(9, 'CPVC Tee', 'It fitting is used to direct and divert water flow in the plumbing system along various diameters across different pressure outlets in the plumbing system. A tee is specifically useful in changing the direction of water flow with minimum to negligible structural changes in the overall piping system.', '../img/cpvc-tee.jpeg', 70, 1, 3, 'p1008', '2023-09-26 17:16:20'),
(10, 'PVC Coupler', 'It are small and in-expensive parts which are very handy and easy to use. PVC couplers are mainly used for commercial, industrial and utility usage which is durable and effective in underground, encased and exposed applications.', '../img/pvc-coupler.jpeg', 110, 1, 1, 'p1009', '2023-09-26 17:19:33'),
(11, 'UPVC Coupler', 'It performs the task of connecting two plain-end drainage pipes and the spigot end of fitting to the plain end of pipe in the drainage system. The uPVC SWR pipe couplers are made from maintenance-free plastic in a variety of sizes that can be used to join pipes and fittings in the drainage system.', '../img/upvc-coupler.jpeg', 60, 1, 2, 'p1010', '2023-09-26 17:21:17'),
(12, 'CPVC Coupler', 'It fitting is used to connect two pipes of varying diameters. The reducer coupler regulates the flow of water in the plumbing system.', '../img/cpvc-coupler.jpeg', 70, 1, 3, 'p1011', '2023-09-26 17:22:28'),
(13, 'PVC Union', 'It connect two pipes by threading together and do not require the traditional glued sealant coupling method to prevent leakage where the two pipes are joined together.', '../img/pvc-union.jpeg', 150, 1, 1, 'p1012', '2023-09-26 17:24:35'),
(14, 'UPVC Union', 'It is a type of joint used to join two pieces of UPVC (unplasticized polyvinyl chloride) pipe together. The union consists of two parts that fit together to create a tight seal.', '../img/upvc-union.jpeg', 120, 1, 2, 'p1013', '2023-09-26 17:25:46'),
(15, 'CPVC Union', 'It is a high-temperature plastic pressure piping system introduced for potable plumbing. It has also been used extensively in fire sprinkler systems. This material is also used for many industrial and process piping applications.', '../img/cpvc-union.jpeg', 140, 1, 3, 'p1014', '2023-09-26 17:26:44'),
(16, 'PVC Solution', 'It can be made more flexible and softer by adding plasticizers such as phthalate and can be bent as per requirement. PVC is an intrinsic flame retardant. It offers good tensile strength and is rigid by nature. It is economical and is an affordable solution.', '../img/pvc-solution.jpeg', 400, 1, 1, 'p1015', '2023-09-26 17:32:12'),
(17, 'UPVC Solution', 'It is used to create a permanent joint between two components, such as, between a pipe and a fitting. The adhesive is made out of resin which is ideal for joining components within the range of ½ – 2 inches in diameter.', '../img/upvc-Solution.jpeg', 300, 1, 2, 'p1016', '2023-09-26 17:33:51'),
(18, 'CPVC Solution', 'It is used to create a permanent joint between two components, such as, between a pipe and a fitting. The adhesive is made out of resin which is ideal for joining component width in the range of ½ – 2 inches in diameter.', '../img/cpvc-solution.jpeg', 400, 1, 3, 'p1017', '2023-09-26 17:50:07');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(10) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `user_pass` varchar(255) NOT NULL,
  `timestamp` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `user_email`, `user_pass`, `timestamp`) VALUES
(1, 'c@gmail.com', '$2y$10$c7guHpGzauuZ6yqMZyNWA.FILYvWgzh809MmGHL/4V./5kKwvxOTu', '2023-10-15 10:38:59'),
(2, 'b@gmail.com', '$2y$10$g5Kn1KMQOJNtJl0RXFuEiuK/yaJwqPQoGRR4Us7hWQUmRm5WiTe52', '2023-10-15 22:22:30'),
(3, 'd@email.com', '$2y$10$6hkjqLRMMTfRhYkV9iZeP.rbCKJjKDeMZbPNYskqCTL4zUB1dFTXa', '2023-10-16 00:36:55'),
(4, 'yash@gmail.com', '$2y$10$xtZamxvMdShZuM2ReCNB8u6RZdbaoIJeGc.fQoOt/ZKJXsjNo/1My', '2023-10-16 13:18:37'),
(5, 'vijaya@gmail.com', '$2y$10$LcPM5OLpA5hZxYGmtXJdcO6CLqj2tayxayph2bMAgZ3P0JI2LTOdi', '2023-10-22 19:29:35'),
(6, 'kishan@gmail.com', '$2y$10$OnKZvWwcy1k/2mAVhFonL.LBI8DlnsVnEkoBke.4w0L.UPCLnWFN6', '2023-11-09 21:48:41');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`cart_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `cart_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=84;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `category_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
