<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Plumbing Product</title>
    <link rel="icon" type="image/x-icon" href="../img/logo.ico" />
    <link rel="stylesheet" href="../css/style.css">
    <link rel='stylesheet'
        href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.min.css' />
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.9.0/css/all.min.css' />
</head>

<body>

    <?php
    include '../partials/nav.php';
    ?>
    <!-- Alert message -->
    <div id="message"></div>

    <!-- Plumbing Categories & Accessories -->
    <div class="container mt-3">
        <div class="pricing-header px-3 py-3 pt-md-5 pb-md-4 mx-auto text-center">
            <h1 class="display-4">Plumbing Categories & Accessories</h1>
        </div>
        <p class="lead">A plumbing fixture is a part that is connected to a plumbing system and carries water through a
            building. The most common plumbing fixtures are bathtubs, sinks, showers, tubs, toilets and faucets.
            While a fixture can be fixed into walls or the floor, a fitting is an item that can be hung by a hook, screw
            or nail.</p>
    </div>

    <div class="container">
        <hr>
    </div>

    <!-- Plumbing Pipes Categories -->
    <div class="container">
        <div class="pricing-header px-3 py-3 pt-md-5 pb-md-4 mx-auto text-center">
            <h1 class="display-4">Plumbing Pipes Categories</h1>
        </div>
        <p class="lead">Types of Pipes for the Plumbing Industry Common plumbing pipes are PVC pipes, CPVC Pipes, UPVC
            Pipes, Cast Iron and galvanized steel pipes, etc. They are mainly used for water distribution purposes.</p>
    </div>

    <!-- Plubing Product -->
    <!-- Displaying Products Start -->
    <div class="container">
        <div class="row mx-3">
            <?php
            include '../partials/conn.php';
            $stmt = $conn->prepare('SELECT * FROM product LIMIT 3 OFFSET 0');
            $stmt->execute();
            $result = $stmt->get_result();
            while ($row = $result->fetch_assoc()):
                $id = $row['product_id'];
                $cat = $row['product_name'];
                $desc = $row['product_desc'];
                $img = $row['product_image'];
                $price = number_format($row['product_price'], 2);
                $qty = $row['product_qty'];
                $pcode = $row['product_code'];
                echo '
                <div class="col-md-4 my-4 mx-0">
                    <div class="card border border-dark" style="width: 16rem;">
                        <div class="card p-2 border-secondary">
                            <a href="items.php?productid=' . $id . '" class="">
                            <img src="' . $img . '" class="card-img-top border-bottom border-dark" height="250"></a>
                                <div class="card-body p-1">
                                    <h4 class="card-title text-center text-info">
                                        ' . $cat . '
                                    </h4>
                                    <h5 class="card-text text-center text-danger"><i class="fas fa-rupee-sign"></i>&nbsp;&nbsp;' . $price . '
                                    </h5>
                                </div>
                                
                            <div class="card-footer p-1">
                            <form action="" class="form-submit">
                                <div class="row p-2">
                                    <div class="col-md-7 py-1 pl-4">
                                        <b>Quantity : </b>
                                    </div>
                                    <div class="col-md-5">
                                        <input type="number" class="form-control pqty" value="' . $qty . '">
                                    </div>
                                </div>
                                <input type="hidden" class="pid" value="' . $id . '">
                                <input type="hidden" class="pname" value="' . $cat . '">
                                <input type="hidden" class="pprice" value="' . $price . '">
                                <input type="hidden" class="pimage" value="' . $img . '">
                                <input type="hidden" class="pcode" value="' . $pcode . '">
                                <div class="row-2">';
                if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
                    echo '
                                    <button class="col my-2 mx-0 btn btn-primary addItemBtn"><i
                                            class="fas fa-cart-plus"></i>&nbsp;&nbsp;Add to
                                        cart</button>';
                } else {
                    echo '<button class="col my-2 mx-0 btn btn-primary"><i
                                            class="fas fa-cart-plus"></i>&nbsp;&nbsp;Add to
                                        cart</button>';
                }
                echo '
                                        <a href="items.php?productid=' . $id . '" class="col btn btn-info">View Product</a>
                                </div>
                            </form>
                            
                        </div>
                    </div>
                </div>
            </div>';
            endwhile; ?>
        </div>
    </div>
    <!-- Displaying Products End -->

    <!-- Plumbing Accessories Categories -->
    <div class="container">
        <div class="pricing-header px-3 py-3 pt-md-5 pb-md-4 mx-auto text-center">
            <h1 class="display-4">Plumbing Accessories</h1>
        </div>
        <p class="lead">These fittings are used in plumbing to manipulate the conveyance of water, gas, or
            liquid waste
            in domestic or commercial environments, within a system of pipes or tubes.</p>
    </div>

    <!-- Plumbing Accessories -->
    <!-- Displaying Products Start -->
    <div class="container">
        <div class="row mx-3 mt-2 pb-3">
            <?php
            include '../partials/conn.php';
            $stmt = $conn->prepare('SELECT * FROM product LIMIT 50 OFFSET 3');
            $stmt->execute();
            $result = $stmt->get_result();
            while ($row = $result->fetch_assoc()):
                $id = $row['product_id'];
                $cat = $row['product_name'];
                $desc = $row['product_desc'];
                $img = $row['product_image'];
                $price = number_format($row['product_price'], 2);
                $qty = $row['product_qty'];
                $pcode = $row['product_code'];
                echo '
                <div class="col-md-4 my-4">
                    <div class="card border border-dark" style="width: 16rem;">
                        <div class="card p-2 border-secondary">
                            <a href="items.php?productid=' . $id . '" class="">
                            <img src="' . $img . '" class="card-img-top border-bottom border-dark" height="250"></a>
                                <div class="card-body p-1">
                                    <h4 class="card-title text-center text-info">
                                        ' . $cat . '
                                    </h4>
                                    <h5 class="card-text text-center text-danger"><i class="fas fa-rupee-sign"></i>&nbsp;&nbsp;' . $price . '
                                    </h5>
                                </div>
                                
                            <div class="card-footer p-1">
                            <form action="" class="form-submit">
                                <div class="row p-2">
                                    <div class="col-md-7 py-1 pl-4">
                                        <b>Quantity : </b>
                                    </div>
                                    <div class="col-md-5">
                                        <input type="number" class="form-control pqty" value="' . $qty . '">
                                    </div>
                                </div>
                                <input type="hidden" class="pid" value="' . $id . '">
                                <input type="hidden" class="pname" value="' . $cat . '">
                                <input type="hidden" class="pprice" value="' . $price . '">
                                <input type="hidden" class="pimage" value="' . $img . '">
                                <input type="hidden" class="pcode" value="' . $pcode . '">
                                <div class="row-2">
                                ';
                if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
                    echo '
                                    <button class="col my-2 mx-0 btn btn-primary addItemBtn"><i
                                            class="fas fa-cart-plus"></i>&nbsp;&nbsp;Add to
                                        cart</button>';
                } else {
                    echo '<button class="col my-2 mx-0 btn btn-primary"><i
                                            class="fas fa-cart-plus"></i>&nbsp;&nbsp;Add to
                                        cart</button>';
                }
                echo '
                                        <a href="items.php?productid=' . $id . '" class="col btn btn-info">View Product</a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>';
            endwhile; ?>
        </div>
    </div>
    <!-- Displaying Products End -->

    <?php
    include "../partials/footer.php";
    ?>

    <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js'></script>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/js/bootstrap.min.js'></script>

    <script type="text/javascript">
        $(document).ready(function () {

            // Send product details in the server
            $(".addItemBtn").click(function (e) {
                e.preventDefault();
                var $form = $(this).closest(".form-submit");
                var pid = $form.find(".pid").val();
                var pname = $form.find(".pname").val();
                var pprice = $form.find(".pprice").val();
                var pimage = $form.find(".pimage").val();
                var pcode = $form.find(".pcode").val();

                var pqty = $form.find(".pqty").val();

                $.ajax({
                    url: '../partials/action.php',
                    method: 'post',
                    data: {
                        pid: pid,
                        pname: pname,
                        pprice: pprice,
                        pqty: pqty,
                        pimage: pimage,
                        pcode: pcode
                    },
                    success: function (response) {
                        $("#message").html(response);
                        window.scrollTo(0, 0);
                        load_cart_item_number();
                    }
                });
            });

            // Load total no.of items added in the cart and display in the navbar
            load_cart_item_number();

            function load_cart_item_number() {
                $.ajax({
                    url: '../partials/action.php',
                    method: 'get',
                    data: {
                        cartItem: "cart_item"
                    },
                    success: function (response) {
                        $("#cart-item").html(response);
                    }
                });
            }
        });
    </script>
</body>

</html>