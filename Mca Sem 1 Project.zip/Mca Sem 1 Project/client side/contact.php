<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css"
        integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <title>Plumbing Product</title>
    <link rel="icon" type="image/x-icon" href="../img/logo.ico" />
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.9.0/css/all.min.css' />
</head>

<body class="mt-5">
    <?php
    include "../partials/conn.php";
    include "../partials/nav.php";
    ?>

    <div class="container">
        <div class="jumbotron mt-5">
            <h1 class="display-4">Contact</h1>
            <hr class="my-4">
            <ul class="lead mt-2 text-dark" style="list-style-type: none;">

                <li><a href="#" title="facebook"><i class='fab fa-facebook' style='font-size:24px; color:blue;'></i>
                        Plumbing Product</a>
                </li>

                <li><a href="#" title="instagram"><i class='fab fa-instagram' style='font-size:24px; color:blue;'></i>
                        Plumbing_Product_offical</a></li>

                <li><a href="#" title="youtube"><i class='fab fa-youtube' style='font-size:24px; color:blue;'></i>
                        Plumbing_Product</a>
                </li>

                <li><a href="#" title="twitter"><i class='fab fa-twitter' style='font-size:24px; color:blue;'></i>
                        Plumbing@Product</a>
                </li>

            </ul>
            <!-- <p class="lead"></p> -->
            <hr class="my-4">
            <p>It is our My website contact in Social Media</p>
            <a class="btn btn-primary btn-lg" href="#" role="button">Learn more</a>
        </div>
    </div>

    <?php
    include "../partials/footer.php";
    ?>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"
        integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"
        integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/js/bootstrap.min.js"
        integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous">
    </script>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js'></script>
    <script type="text/javascript">
    $(document).ready(function() {

        // Load total no.of items added in the cart and display in the navbar
        load_cart_item_number();

        function load_cart_item_number() {
            $.ajax({
                url: '../partials/action.php',
                method: 'get',
                data: {
                    cartItem: "cart_item"
                },
                success: function(response) {
                    $("#cart-item").html(response);
                }
            });
        }
    });
    </script>
</body>

</html>