<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css"
        integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <title>Plumbing Product</title>
    <link rel="icon" type="image/x-icon" href="../img/logo.ico" />
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.9.0/css/all.min.css' />

</head>

<body class="mt-5">

    <?php
    include '../partials/conn.php';
    include "../partials/nav.php";
    ?>
    <div class="container">

        <!-- Gallery Row 1 -->
        <div class="row">
            <div class="col bg-dark mr-md-3 pt-3 px-3 pt-md-5 px-md-5 w-50 text-center text-white overflow-hidden">
                <div class="my-3 py-3">
                    <h2 class="display-5">PVC Pipes</h2>
                    <p class="lead">plumbing, sewage and drainage systems, drinking water distribution, etc.</p>
                </div>
                <div class="bg-light shadow-sm mx-auto" style="width: 70%; height: 100%; border-radius: 21px 21px 0 0;">
                    <img src="../img/card1.jpeg" style="border-radius: inherit; width: -webkit-fill-available;" alt="">
                    <!-- <img src="../img/card1.jpeg" style="w-70 border-radius: 21px 21px 0 0;" alt="" srcset=""> -->
                </div>
            </div>
            <div class="col bg-light mr-md-3 pt-3 px-3 pt-md-5 px-md-5 w-50 text-center  overflow-hidden border">
                <div class="my-3 py-3">
                    <h2 class="display-5">UPVC Pipes</h2>
                    <p class="lead">It used supplying potable water in bathrooms, kitchens, etc.</p>
                </div>
                <div class="bg-light shadow-sm mx-auto mb-auto h-auto border"
                    style="width: 70%; height: 100%; border-radius: 21px 21px 0 0;">
                    <img src="../img/card2.jpeg" style="border-radius: inherit; width: -webkit-fill-available;" alt="">
                </div>
            </div>
        </div>

        <!-- Gallery Row 2 -->
        <div class="row mt-3">
            <div class="col bg-light mr-md-3 pt-3 px-3 pt-md-5 px-md-5 w-50 text-center  overflow-hidden border">
                <div class="my-3 py-3">
                    <h2 class="display-5">CPVC Pipes</h2>
                    <p class="lead">high-temperature plastic pressure piping system introduced for potable plumbing in
                        1959.</p>
                </div>
                <div class="bg-light shadow-sm mx-auto border"
                    style="width: 70%; height: 100%; border-radius: 21px 21px 0 0;">
                    <img src="../img/card3.jpeg" style=" border-radius: inherit; width: -webkit-fill-available;" alt=""
                        srcset="">
                    <!-- <img src="../img/card1.jpeg" style="w-70 border-radius: 21px 21px 0 0;" alt="" srcset=""> -->
                </div>
            </div>
            <div class="col bg-dark mr-md-3 pt-3 px-3 pt-md-5 px-md-5 w-50 text-center text-white overflow-hidden">
                <div class="my-3 py-3">
                    <h2 class="display-5">PVC Solution</h2>
                    <p class="lead">It is a homopolymer featuring molecular chains with few branches; </p>
                </div>
                <div class="bg-dark shadow-sm mx-auto" style="width: 70%; height: 100%; border-radius: 21px 21px 0 0;">
                    <img src="../img/pvc-solution.jpeg" style="border-radius: inherit; width: -webkit-fill-available;"
                        alt="" srcset="">
                    <!-- <img src="../img/card1.jpeg" style="w-70 border-radius: 21px 21px 0 0;" alt="" srcset=""> -->
                </div>
            </div>
        </div>

        <!-- Gallery Row 3 -->
        <div class="row mt-3">
            <div class="col bg-dark mr-md-3 pt-3 px-3 pt-md-5 px-md-5 w-50 text-center text-white overflow-hidden">
                <div class="my-3 py-3">
                    <h2 class="display-5">UPVC Solution</h2>
                    <p class="lead">joining uPVC pipes & fittings for low pressure and drainage system.</p>
                </div>
                <div class="bg-light shadow-sm mx-auto" style="width: 70%; height: 100%; border-radius: 21px 21px 0 0;">
                    <img src="../img/upvc-solution.jpeg" style="border-radius: inherit; width: -webkit-fill-available;"
                        alt="" srcset="">
                    <!-- <img src="../img/card1.jpeg" style="w-70 border-radius: 21px 21px 0 0;" alt="" srcset=""> -->
                </div>
            </div>
            <div class="col bg-light mr-md-3 pt-3 px-3 pt-md-5 px-md-5 w-50 text-center  overflow-hidden border">
                <div class="my-3 py-3">
                    <h2 class="display-5">CPVC Solution</h2>
                    <p class="lead">It used to create a permanent joint between two components, such as, between a pipe
                        and a fitting.</p>
                </div>
                <div class="bg-light shadow-sm mx-auto border"
                    style="width: 70%; height: 100%; border-radius: 21px 21px 0 0;">
                    <img src="../img/cpvc-solution.jpeg" style=" border-radius: inherit; width: -webkit-fill-available;"
                        alt="" srcset="">
                    <!-- <img src="../img/card1.jpeg" style="w-70 border-radius: 21px 21px 0 0;" alt="" srcset=""> -->
                </div>
            </div>
        </div>
    </div>
    <?php
    include "../partials/footer.php";
    ?>

    <script>
    window.jQuery || document.write('<script src="/docs/4.4/assets/js/vendor/jquery.slim.min.js"><\/script>')
    </script>
    <script src="/docs/4.4/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-6khuMg9gaYr5AxOqhkVIODVIvm9ynTT5J4V1cfthmT+emCG6yVmEZsRHdxlotUnm" crossorigin="anonymous">
    </script>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"
        integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"
        integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/js/bootstrap.min.js"
        integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous">
    </script>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js'></script>
    <script type="text/javascript">
    $(document).ready(func tion() {

        // Load total no.of items added in the cart and display in the navbar
        load_cart_item_number();

        function load_cart_item_number() {
            $.ajax({
                url: '../partials/action.php',
                method: 'get',
                data: {
                    cartItem: "cart_item"
                },
                success: func tion(response) {
                    $("#cart-item").html(response);
                }
            });
        }
    });
    </script>
</body>

</html>