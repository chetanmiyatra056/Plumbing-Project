<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css"
        integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <title>Plumbing Product</title>
    <link rel="icon" type="image/x-icon" href="../img/logo.ico" />
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <script src="../js/script.js"></script>
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.9.0/css/all.min.css' />

</head>

<body class="mt-5">
    <?php
    //session_start();
    include '../partials/conn.php';
    include "../partials/nav.php";
    ?>
    <div id="message"></div>

    <!-- View Product -->
    <?php
    $id = $_GET['productid'];
    $sql = "SELECT * FROM `product` WHERE product_id = '$id'";
    // $sqls = "SELECT * FROM `product` WHERE product_name LIKE '%Pipes%'";
    $result = mysqli_query($conn, $sql);
    // $results = mysqli_query($conn, $sqls);
    while ($row = mysqli_fetch_assoc($result)) {
        // $proid = $row['product_id'];
        $proid = $id;
        $proname = $row['product_name'];
        $prodesc = $row['product_desc'];
        $proimg = $row['product_image'];
        $proprice = $row['product_price'];
        $type = $row['product_code'];
        $qty = $row['product_qty'];

        echo '
            <div class="container my-5 d-flex" style="top:10px">
                <div class="row jumbotron">
                    <div class="col" style="display: contents">
                        <img src="' . $proimg . '" class="border border-dark" alt="loading" height="300px">
                    </div>
                    <div class="col ml-3">
                        <h1 class="display-4">
                            ' . $proname . '
                        </h1>
                        <p class="lead">
                            ' . $prodesc . '
                        </p>
                        <hr class="my-4">';
        $sum = $proprice / 10;
        if ($type <= "p1002") // Pipes
        {
            echo '
                                <h3>
                                    This Product Price:
                                    ₹' . $proprice . ' (10 Feet Pipe) 
                                </h3>
                                <h4>
                                    1 Feet Pipe = ₹' . $sum . '
                                </h4>
                            ';
        } else { // <!-- Accessories -->
            echo '
                                <h3>
                                    This Product Price:
                                    ₹' . $proprice . '
                                </h3>
                                <h4>
                                    (price/Item)
                                </h4>
                            ';
        }
        echo '
                        <form action="items.php" class="form-submit">
                            <div class="row p-2">
                                <div class="col-md-2 py-1 pl-4">
                                    <b>Quantity: </b>
                                </div>
                                <div class="col-md-3">
                                    <input type="number" class="form-control pqty" value="' . $qty . '">
                                </div>
                            </div>
                            <input type="hidden" class="pid" value="' . $proid . '">
                            <input type="hidden" class="pname" value="' . $proname . '">
                            <input type="hidden" class="pprice" value="' . $proprice . '">
                            <input type="hidden" class="pimage" value="' . $proimg . '">
                            <input type="hidden" class="pcode" value="' . $type . '">
                            <div class="row-2">';
        if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
            echo '
                                <button class="row mx-0 btn btn-primary addItemBtn"><i class="fas fa-cart-plus"></i>&nbsp;&nbsp;Add to cart</button>';
        } else {
            echo '
                                <!-- <button class="row mx-0 btn btn-primary"><i class="fas fa-cart-plus"></i>&nbsp;&nbsp;Add to cart</button> -->
                                <a href="#"  class="row mx-0 btn btn-primary"><i class="fas fa-cart-plus"></i>&nbsp;&nbsp;Add to cart</a>
                                ';
        }
        echo '
                                <a href="product.php" class="row mx-0 btn btn-info"><i class="fa fa-arrow-circle-left"></i>&nbsp;&nbsp;Back to Products</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>';
    } ?>
    <?php
    include "../partials/footer.php";
    ?>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"
        integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous">
        </script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"
        integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous">
        </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/js/bootstrap.min.js"
        integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous">
        </script>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js'></script>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/js/bootstrap.min.js'></script>
    <script type="text/javascript">
        $(document).ready(function () {

            // Send product details in the server
            $(".addItemBtn").click(function (e) {
                e.preventDefault();
                var $form = $(this).closest(".form-submit");
                var pid = $form.find(".pid").val();
                var pname = $form.find(".pname").val();
                var pprice = $form.find(".pprice").val();
                var pimage = $form.find(".pimage").val();
                var pcode = $form.find(".pcode").val();

                var pqty = $form.find(".pqty").val();

                $.ajax({
                    url: '../partials/action.php',
                    method: 'post',
                    data: {
                        pid: pid,
                        pname: pname,
                        pprice: pprice,
                        pqty: pqty,
                        pimage: pimage,
                        pcode: pcode
                    },
                    success: function (response) {
                        $("#message").html(response);
                        window.scrollTo(0, 0);
                        load_cart_item_number();
                    }
                });
            });

            // Load total no.of items added in the cart and display in the navbar
            load_cart_item_number();

            function load_cart_item_number() {
                $.ajax({
                    url: '../partials/action.php',
                    method: 'get',
                    data: {
                        cartItem: "cart_item"
                    },
                    success: function (response) {
                        $("#cart-item").html(response);
                    }
                });
            }
        });
    </script>
</body>

</html>