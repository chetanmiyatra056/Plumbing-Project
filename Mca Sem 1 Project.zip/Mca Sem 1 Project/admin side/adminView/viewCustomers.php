<div>
    <a href="./home.php" style="float: right;"><i class="fa fa-close"
            style="padding-top: 5px; font-size:30px; color:#000;"></i></a>
    <h2>All Customers</h2>
    <table class="table ">
        <thead>
            <tr>
                <th class="text-center">S.N.</th>
                <th class="text-center">Username </th>
                <th class="text-center">Timestamp</th>
            </tr>
        </thead>
        <?php
        include "../conn.php";
        $sql = "SELECT * from users where user_id";
        $result = $conn->query($sql);
        $count = 1;
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {

                ?>
        <tr>
            <td>
                <?= $count ?>
            </td>
            <td>
                <?= $row["user_email"] ?>
            </td>
            <td>
                <?= $row["timestamp"] ?>
            </td>
        </tr>
        <?php
                $count = $count + 1;

            }
        }
        ?>
    </table>