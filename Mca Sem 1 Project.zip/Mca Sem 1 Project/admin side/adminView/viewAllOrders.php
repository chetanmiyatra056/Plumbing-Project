<div id="ordersBtn">
    <a href="./home.php" style="float: right;"><i class="fa fa-close"
            style="padding-top: 5px; font-size:30px; color:#000;"></i></a>
    <h2>Order Details</h2>
    <table class="table table-striped">
        <thead>
            <tr>
                <th>O.N.</th>
                <th>Customer</th>
                <!-- <th style="">Email</th> -->
                <th>Phone</th>
                <th>Address</th>
                <th>Payment method</th>
                <th>Products</th>
                <th>Amount</th>
                <th>Order Status</th>
                <th>Payment Status</th>
            </tr>
        </thead>
        <?php
        include_once "../conn.php";
        $sql = "SELECT * from orders";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                ?>
        <tr>
            <td>
                <?= $row["order_id"] ?>
            </td>
            <td>
                <?= $row["name"] ?>
            </td>
            <!-- <td>
                <?= $row["email"] ?>
            </td> -->
            <td>
                <?= $row["phone"] ?>
            </td>
            <td>
                <?= $row["address"] ?>
            </td>
            <td>
                <?= $row["pay_mode"] ?>
            </td>
            <td>
                <?= $row["products"] ?>
            </td>
            <td>
                <?= $row["amount_paid"] ?>
            </td>
            <?php
                    if ($row["order_status"] == 0) {

                        ?>
            <td><button class="btn btn-danger" onclick="ChangeOrderStatus('<?= $row['order_id'] ?>')">Pending </button>
            </td>
            <?php

                    } else {
                        ?>
            <td><button class="btn btn-success"
                    onclick="ChangeOrderStatus('<?= $row['order_id'] ?>')">Delivered</button></td>

            <?php
                    }
                    if ($row["pay_status"] == 0) {
                        ?>
            <td><button class="btn btn-danger" onclick="ChangePay('<?= $row['order_id'] ?>')">Unpaid</button></td>
            <?php

                    } else if ($row["pay_status"] == 1) {
                        ?>
            <td><button class="btn btn-success" onclick="ChangePay('<?= $row['order_id'] ?>')">Paid </button></td>
            <?php
                    }
                    ?>

            <!-- <td><a class="btn btn-primary openPopup" data-href="./adminView/viewEachOrder.php?orderID=<?= $row['order_id'] ?>"
              href="javascript:void(0);">View</a></td> -->
        </tr>
        <?php

            }
        }
        ?>

    </table>

</div>
<!-- Modal -->
<div class="modal fade" id="viewModal" role="dialog">
    <div class="modal-dialog modal-lg">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">

                <h4 class="modal-title">Order Details</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="order-view-modal modal-body">

            </div>
        </div>
        <!--/ Modal content-->
    </div><!-- /Modal dialog-->
</div>
<script>
//for view order modal  
$(document).ready(function() {
    $('.openPopup').on('click', function() {
        var dataURL = $(this).attr('data-href');

        $('.order-view-modal').load(dataURL, function() {
            $('#viewModal').modal({
                show: true
            });
        });
    });
});
</script>