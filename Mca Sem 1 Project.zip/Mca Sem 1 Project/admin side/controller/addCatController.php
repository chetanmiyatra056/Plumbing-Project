<?php
include "../conn.php";

if (isset($_POST['upload'])) {

    $Catname = $_POST['c_name'];
    $Catdesc = $_POST['c_desc'];
    $name = $_FILES['file']['name'];
    $temp = $_FILES['file']['tmp_name'];

    $location = "./uploads/";
    $image = $location . $name;

    $target_dir = "../uploads/";
    $finalImage = $target_dir . $name;

    move_uploaded_file($temp, $finalImage);

    $sql = " INSERT INTO `categories` (`category_name`, `category_description`, `category_image`) 
    VALUES ('$Catname', '$Catdesc','$image')";

    $result = mysqli_query($conn, $sql);

    if (!$result) {
        echo mysqli_error($conn);
        header("Location: ../home.php?category=error");
    } else {
        echo "Records added successfully.";
        header("Location: ../home.php?category=success");
    }

}

?>