<?php
include_once "../conn.php";

if (isset($_POST['upload'])) {

    $ProductName = $_POST['p_name'];
    $desc = $_POST['p_desc'];
    $price = $_POST['p_price'];
    $category = $_POST['category'];
    $Productqty = $_POST['p_qty'];
    $Productcode = $_POST['p_code'];

    $name = $_FILES['file']['name'];
    $temp = $_FILES['file']['tmp_name'];

    $location = "./uploads/";
    $image = $location . $name;

    $target_dir = "../uploads/";
    $finalImage = $target_dir . $name;

    move_uploaded_file($temp, $finalImage);

    // Check whether Product Code exists
    $existSql = "SELECT * FROM `product` WHERE product_code = '$Productcode'";
    $result = mysqli_query($conn, $existSql);
    $numRows = mysqli_num_rows($result);
    if ($numRows > 0) {
        $showError = "This Product Code already in used";
        header("Location: ../home.php?product=error=$showError");
    } else {
        $sql = "INSERT INTO `product` (`product_name`, `product_desc`, `product_image`, `product_price`, `product_qty`, `category_id`, `product_code`) VALUES ('$ProductName', '$desc', '$image', '$price', '$Productqty', '$category', '$Productcode')";
        $insert = mysqli_query($conn, $sql);

        if (!$insert) {
            echo mysqli_error($conn);
        } else {
            echo "Records added successfully.";
        }
    }
}

?>