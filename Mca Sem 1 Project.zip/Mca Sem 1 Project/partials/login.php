<?php

$showError = "false";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    include '../partials/conn.php';
    $email = $_POST["loginEmail"];
    $pass = $_POST["loginPass"];

    // Login
    $sql = "Select * from users where user_email = '$email'";
    $result = mysqli_query($conn, $sql);
    $numRows = mysqli_num_rows($result);

    if ($numRows == 1) {
        $row = mysqli_fetch_assoc($result);

        if (password_verify($pass, $row['user_pass'])) {
            session_start();
            $_SESSION['loggedin'] = true;
            $_SESSION['sno'] = $row['sno'];
            $_SESSION['useremail'] = $email;
            header("location:/plumbing product/client side/index.php");
            echo 'login in ' . $email;
            // exit();
        } else {
            // echo var_dump($row['user_pass']);
            echo 'unable to login';
        }
    }
}



?>