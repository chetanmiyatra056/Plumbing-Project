<?php

session_start();
session_unset();
session_destroy();
header("location:/plumbing product/client side/index.php");
exit;

?>