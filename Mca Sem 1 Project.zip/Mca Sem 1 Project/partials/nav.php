<?php

session_start();

echo '
    <!-- Navbar -->
    <nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-primary" >
    <a class="navbar-brand" href="index.php">
        <img src="../img/logo.ico" width="30" height="30" class="d-inline-block align-top" alt="">
        Plumbing Product
    </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto" style="font-size: 20px;">
            <li class="nav-item active">
                <a class="nav-link" href="index.php">Home</a>
            </li>
            <li class="nav-item active">
                <a class="nav-link" href="gallery.php">Gallery</a>
            </li>
            <li class="nav-item active">
                <a class="nav-link" href="product.php">Products</a>
            </li>
            <li class="nav-item active">
                <a class="nav-link" href="about.php">About Us</a>
            </li>
            <li class="nav-item active">
                <a class="nav-link" href="contact.php">Contact Us</a>
            </li>';

// Add to cart Icon
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
    echo '
            <li class="nav-item">
                    <a class="nav-link" href="cart.php" title="My Cart"><i class="fas fa-shopping-cart"></i> <span id="cart-item"
                    class="badge badge-danger"></span></a>
            </li>';
} else {
    echo '
            <li class="nav-item">
                    <a class="nav-link" href="#" title="My Cart"><i class="fas fa-shopping-cart"></i></a>
            </li>';
}
echo '</ul>';

// Display Login name
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
    echo '<form class="form-inline my-2 my-lg-0" method="get" action="search.php">
          <input class="form-control mr-sm-2" name="search" type="search" placeholder="Search" aria-label="Search">
          <button class="btn btn-outline-light my-2 my-sm-0" type="submit">Search</button>
            <p class="text-light my-0 mx-2">Welcome ' . $_SESSION['useremail'] . '</p>
            <div class="mr-2">
            <a role="button" href="../partials/logout.php" class="btn btn-danger my-sm-0">Login Out</a>
            </form>';
} else {
    echo '<form class="form-inline my-2 my-lg-0">
            <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
            <button class="btn btn-outline-light my-2 mx-2 my-sm-0">Search</button>
        </form>
        <div class="mr-2">
            <button class="btn btn-danger" data-toggle="modal" data-target="#loginModal">LogIn</button>
            <button class="btn btn-danger" data-toggle="modal" data-target="#signupModal">SignUp</button>';
}

echo '</div>
</div>
</nav>';

include '../partials/loginmodal.php';
include '../partials/signupmodal.php';

$showErroremail = "Email already in used";
$showErrorpass = "Password do not match";

if (isset($_GET['signupsuccess']) && $_GET['signupsuccess'] == "true") {
    echo '<div id="alert" class="alert alert-success alert-dismissible fade show my-0" role="alert">
          <strong>Success!</strong> Now You can Login.
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>';
}

if (isset($_GET['signupsuccess']) && $_GET['signupsuccess'] == "false") {
    echo '<div id="alert" class="alert alert-danger alert-dismissible fade show my-0" role="alert" >
          <strong>Error!</strong> ' . $showErroremail . ' or ' . $showErrorpass . '
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>';
}
?>