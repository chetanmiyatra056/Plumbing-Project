<!-- Footer -->
<footer class="text-muted bg-dark mt-5 p-2">
    <div class="float-right pr-5">
        <p>
            <a href="#"><i class='fas fa-arrow-circle-up' style='font-size:24px'></i>
                Back to Top</a>
        </p>
        <a href="#" title="facebook"><i class='fab fa-facebook' style='font-size:24px; color:blue;'></i></a>
        <a href="#" title="instagram"><i class='fab fa-instagram' style='font-size:24px; color:blue;'></i></a>
        <a href="#" title="youtube"><i class='fab fa-youtube' style='font-size:24px; color:blue;'></i></a>
        <a href="#" title="twitter"><i class='fab fa-twitter' style='font-size:24px; color:blue;'></i></a>
    </div>
    <div class="text-primary">
        <p>&copy; 2024 Plumbing Product</p>
        <p>Thank You form Visiting our website.
        </p>
    </div>
</footer>